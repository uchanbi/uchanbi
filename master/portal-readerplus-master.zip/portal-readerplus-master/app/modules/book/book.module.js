'use strict';

angular.module('app.book', [])
.controller('BookCtrl', function ($scope, BookService, $stateParams, $modal, flowFactory) {

});
