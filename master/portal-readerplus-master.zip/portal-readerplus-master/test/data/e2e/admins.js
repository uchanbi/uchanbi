module.exports = [{
    "username": "test_school_admin@pearson.com",
    "password": "TldE996gbhoO",
    "countryCode" : "US"
  },
  {
    "username": "admin@not.assigned.com",
    "password": "hudson102",
    "countryCode" : "US"
  },
  {
    "username": "just@an.admin",
    "password": "hudson123",
    "countryCode" : "US"
  }
]
