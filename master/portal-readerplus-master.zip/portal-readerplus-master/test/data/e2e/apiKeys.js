module.exports = [{
    key: 'dh37fgj492je',
    secret: 'werxhqb98rpaxn39848xrunpaw3489ruxnpa98w4rxn',
    algorithm: 'sha256',
    appId: '5487201fbab5214b54f3ecc1'
  }
]