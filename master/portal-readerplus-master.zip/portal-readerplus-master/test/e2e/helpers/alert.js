var commands = {};

module.exports = {
  url: 'http://localhost:3001',
  commands: [commands],
  elements: {
    alert: {
      selector: '.alert div span'
    }
  }
};
